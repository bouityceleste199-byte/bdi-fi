import React, { useState } from 'react';
export default function PasswordInput(props) {
  const [visible, setVisible] = useState(false);
  return <span style={{
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap'
  }}>
      <input {...props} type={visible ? 'text' : 'password'} style={{
      flex: '1 1 160px',
      minWidth: 0
    }} />
      <button type='button' className='secondary' aria-label={visible ? 'Masquer mon mot de passe' : 'Afficher mon mot de passe'} aria-pressed={visible} onClick={() => setVisible(!visible)} style={{
      width: 'auto',
      flex: '0 0 auto',
      padding: '8px 10px',
      marginTop: 6,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6
    }}>
        <svg aria-hidden='true' width='20' height='20' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='1.8'>
          <path d='M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z' />
          <circle cx='12' cy='12' r='3' />
          {visible && <path d='M3 3l18 18' />}
        </svg>
        {visible ? 'Masquer' : 'Afficher'}
      </button>
    </span>;
}
