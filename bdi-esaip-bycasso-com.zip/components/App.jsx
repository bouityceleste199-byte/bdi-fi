import React, { useState, useEffect } from 'react';
import PasswordInput from './PasswordInput.jsx';
import FinanceTools from './FinanceTools.jsx';
const BASE = 'https://ynhq5b76umgdn5km65eehury5a0dxcnm.lambda-url.us-east-1.on.aws';
const money = n => new Intl.NumberFormat('fr-FR', {
  style: 'currency',
  currency: 'EUR'
}).format(n || 0);
const parseDecimal = value => {
  const text = String(value ?? '').trim().replace(/[\s\u00a0\u202f]/g, '').replace(',', '.');
  if (!text) return 0;
  if (!/^\d+(?:\.\d{0,2})?$/.test(text)) return NaN;
  return Number(text);
};
const specs = {
  budget: {
    label: 'Notre budget',
    c: 'members_budget',
    fields: [['name', 'Nom du BDI'], ['period', 'Période (ex. : année 2026–2027)'], ['date', 'Début', 'date'], ['amount', 'Argent de départ', 'number'], ['reserve', 'Réserve souhaitée', 'number'], ['warning', 'Seuil avertissement (%)', 'number'], ['critical', 'Seuil critique (%)', 'number'], ['description', 'Objectifs et sources de financement']]
  },
  recettes: {
    label: 'Argent reçu',
    c: 'shared_recettes',
    fields: [['name', 'Description'], ['date', 'Date attendue / reçue', 'date'], ['amount', 'Montant', 'number'], ['category', 'Catégorie'], ['source', 'Source'], ['project', 'Projet', 'project'], ['payment', 'Mode de paiement'], ['status', 'Statut', ['Prévu', 'Reçu', 'Annulé']]]
  },
  depenses: {
    label: 'Dépenses',
    c: 'shared_depenses',
    fields: [['name', 'Description'], ['date', 'Date de demande', 'date'], ['paid_date', 'Date de paiement', 'date'], ['amount', 'Montant', 'number'], ['category', 'Catégorie'], ['supplier', 'Fournisseur'], ['project', 'Projet', 'project'], ['status', 'Statut', ['Brouillon', 'Proposée', 'En attente de validation', 'Approuvée', 'Engagée mais non payée', 'Payée', 'Refusée', 'Annulée']], ['description', 'Commentaires et décision']]
  },
  projets: {
    label: 'Projets',
    c: 'shared_projets',
    fields: [['name', 'Nom'], ['description', 'Description et objectifs'], ['responsible', 'Responsable'], ['participants', 'Participants'], ['date', 'Début', 'date'], ['end', 'Échéance', 'date'], ['final_summary', 'Bilan final : résultats et décisions'], ['category', 'Catégorie'], ['amount', 'Coût estimé du projet', 'number'], ['approved', 'Budget approuvé', 'number'], ['status', 'Statut', ['Idée', 'En préparation', 'En attente de validation', 'Approuvé', 'En cours', 'Terminé', 'Suspendu', 'Annulé']]]
  },
  propositions: {
    label: 'Mes propositions',
    c: 'user_propositions',
    fields: [['name', 'Nom'], ['description', 'Objectifs et hypothèses'], ['amount', 'Budget demandé', 'number'], ['quantity', 'Quantité', 'number'], ['unit', 'Prix estimé pour un article', 'number'], ['margin', 'Marge de sécurité (%)', 'number']]
  }
};
export default function App() {
  const [token, setToken] = useState(''),
    [user, setUser] = useState(null),
    [mode, setMode] = useState('login'),
    [signup, setSignup] = useState('invite'),
    [auth, setAuth] = useState({
      email: '',
      password: '',
      name: ''
    }),
    [tab, setTab] = useState('dashboard'),
    [data, setData] = useState({}),
    [msg, setMsg] = useState(''),
    [busy, setBusy] = useState(false),
    [edit, setEdit] = useState(null),
    [form, setForm] = useState({}),
    [filter, setFilter] = useState('');
  async function api(path, body, method = 'GET', t = token) {
    for (let i = 0;; i++) {
      const r = await fetch(BASE + path, {
        method,
        headers: {
          'Content-Type': 'application/json',
          ...(t ? {
            Authorization: 'Bearer ' + t
          } : {})
        },
        ...(body ? {
          body: JSON.stringify(body)
        } : {})
      });
      const j = await r.json().catch(() => ({}));
      if (r.status === 429 && j.success === undefined && i < 4) {
        await new Promise(x => setTimeout(x, 300 * (i + 1)));
        continue;
      }
      if (!j.success) {
        if (r.status === 401) {
          localStorage.removeItem('bdi_session');
          setToken('');
          setUser(null);
          setData({});
        }
        const err = Error(j.message || 'La requête n’a pas abouti. Réessayez.');
        err.code = j.code;
        throw err;
      }
      return j;
    }
  }
  async function listComplete(collection, t) {
    const result = await api('/'+collection, undefined, 'GET', t);
    const items = result.items || [];
    if (items.length >= 200 || Number(result.count || 0) > items.length) throw Error('La liste '+collection+' peut dépasser la limite de lecture. Calculs et exports bloqués : aucune pagination complète n’est disponible dans cette version. Aucune donnée n’a été supprimée.');
    return items;
  }
  async function load(t = token) {
    setBusy(true);
    try {
      const current = await api('/_auth/me', undefined, 'GET', t);
      setUser(current.user);
      const out = {};
      for (const [k, s] of Object.entries(specs)) {
        out[k] = (await listComplete(s.c,t)).map(r => ({
          ...r,
          _collection: s.c
        }));
        if (['recettes', 'depenses', 'projets'].includes(k)) {
          const legacy = {
            recettes: 'members_recettes',
            depenses: 'members_depenses',
            projets: 'members_projets'
          }[k];
          const previous = await listComplete(legacy,t);
          out[k].push(...previous.map(r => ({
            ...r,
            _collection: legacy
          })));
        }
      }
      out.history = await listComplete('members_history',t);
      if (out.budget.length > 1) throw Error('Plusieurs budgets existent. Aucun n’a été supprimé : choisissez le budget actif dans la console avant de calculer.');
      setData(out);
      setMsg('');
    } catch (e) {
      setData({_incomplete:true});
      setMsg(e.message);
    } finally {
      setBusy(false);
    }
  }
  useEffect(() => {
    api('/_auth/settings').then(j => setSignup(j.signup || 'invite')).catch(() => {});
    const t = localStorage.getItem('bdi_session');
    if (t) api('/_auth/me', undefined, 'GET', t).then(j => {
      setToken(t);
      setUser(j.user);
      if (!j.user.must_change_password) load(t);
    }).catch(e => setMsg(e.message));
  }, []);
  async function login(e) {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === 'forgot') {
        setMsg('Demande en cours…');
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 20000);
        try {
          const r = await fetch('https://webhook.casso-websites.com/site-auth/9e423dcf-8536-47e7-a9f0-6502331c159e/forgot', {
            method: 'POST',
            signal: controller.signal,
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              email: auth.email.trim().toLowerCase()
            })
          });
          const j = await r.json().catch(() => ({}));
          if (!r.ok || !j.success) throw Error(j.message || 'La demande n’a pas abouti. Aucun envoi ne peut être confirmé. Réessayez.');
          setMsg(j.message || 'Demande traitée. Si cette adresse correspond à un compte, consultez votre boîte de réception et les courriers indésirables.');
        } catch (error) {
          if (error.name === 'AbortError') throw Error('Le service ne répond pas. L’envoi du lien n’est pas confirmé. Réessayez.');
          if (error instanceof TypeError) throw Error('Impossible de joindre le service de réinitialisation. Vérifiez votre connexion et réessayez.');
          throw error;
        } finally {
          clearTimeout(timer);
        }
        return;
      }
      const j = await api('/_auth/' + (mode === 'signup' ? 'signup' : 'login'), auth, 'POST', '');
      if (j.pending) {
        setMsg(j.message);
        return;
      }
      setToken(j.token);
      setUser(j.user);
      localStorage.setItem('bdi_session', j.token);
      if (!j.user.must_change_password) await load(j.token);
    } catch (e) {
      setMsg(e.message);
      if (e.code === 'account_exists') setMode('login');
    } finally {
      setBusy(false);
    }
  }
  const rows = k => data[k] || [],
    num = (r, k = 'amount') => Math.round(Number(r.data[k] || 0) * 100),
    sum = (rs, k) => rs.reduce((s, r) => s + num(r, k), 0) / 100;
  const b = rows('budget')[0]?.data,
    initial = Number(b?.amount || 0),
    received = sum(rows('recettes').filter(r => r.data.status === 'Reçu')),
    paid = sum(rows('depenses').filter(r => r.data.status === 'Payée')),
    engaged = sum(rows('depenses').filter(r => ['Approuvée', 'Engagée mais non payée'].includes(r.data.status))),
    balance = initial + received - paid,
    forecast = balance - engaged;
  const alerts = [];
  const seen = new Map();
  [...rows('recettes'),...rows('depenses')].forEach(r=>{
    const type=rows('recettes').includes(r)?'recette':'dépense';
    const fingerprint=[type,String(r.data.name||'').trim().toLowerCase(),num(r),r.data.date||'',r.data.project||'',String(r.data.supplier||r.data.source||'').trim().toLowerCase()].join('|');
    if(seen.has(fingerprint)) alerts.push('Doublon possible : '+r.data.name+' ('+money(r.data.amount)+'), même date, montant, projet et fournisseur/source que '+seen.get(fingerprint)+'. Vérifier les deux écritures avant de modifier ; aucune suppression automatique.');
    else seen.set(fingerprint,r.id);
    if(type==='dépense' && r.data.project){const p=rows('projets').find(p=>p.id===r.data.project);if(p && Number(r.data.amount)>Number(p.data.approved||0)) alerts.push(r.data.name+' : '+money(r.data.amount)+' dépasse le budget autorisé du projet '+p.data.name+' ('+money(p.data.approved)+'). Revoir ou refuser cette demande.');}
  });
  rows('projets').forEach(p => {
    const d = p.data,
      cost = sum(rows('depenses').filter(r => r.data.project === p.id && ['Payée', 'Approuvée', 'Engagée mais non payée'].includes(r.data.status))),
      approved = Number(d.approved || 0);
    if (!approved) alerts.push(d.name + ' : aucun budget approuvé. Faire valider le financement.');else if (cost / approved * 100 >= Number(b?.warning || 80)) alerts.push(d.name + ' : ' + money(cost) + ' engagés / payés sur ' + money(approved) + (cost / approved * 100 >= Number(b?.critical || 90) ? ' — seuil critique.' : ' — vigilance.') + ' Revoir les postes restants.');
    if (Number(d.amount) > approved && approved) alerts.push(d.name + ' : prévision supérieure au budget de ' + money(d.amount - approved) + '. Réviser la proposition.');
  });
  rows('depenses').filter(r => r.data.status === 'En attente de validation').forEach(r => alerts.push(r.data.name + ' : ' + money(r.data.amount) + ' en attente de validation.'));
  rows('recettes').filter(r => r.data.status === 'Prévu' && r.data.date && r.data.date < new Date().toISOString().slice(0, 10)).forEach(r => alerts.push(r.data.name + ' : ' + money(r.data.amount) + ' attendus. Vérifier la réception.'));
  if (b && forecast < Number(b.reserve || 0)) alerts.push('Solde prévisionnel ' + money(forecast) + ' inférieur à la réserve souhaitée. Réduire ou différer les engagements.');
  function logout() {
    localStorage.removeItem('bdi_session');
    setToken('');
    setUser(null);
    setData({});
    setEdit(null);
  }
  async function save(e) {
    e.preventDefault();
    setBusy(true);
    try {
      const s = specs[tab],
        old = edit?.id ? rows(tab).find(r => r.id === edit.id) : null;
      const payload = {
        ...form,
        actor: user.name || user.email,
        updated_at: new Date().toISOString()
      };
      if (tab === 'budget') {
        if (payload.warning === undefined || payload.warning === '') payload.warning = 80;
        if (payload.critical === undefined || payload.critical === '') payload.critical = 90;
      }
      if (tab === 'depenses' && user.role !== 'admin') throw Error('Propose cette dépense dans Mes propositions. Seule l’administration peut modifier les dépenses officielles.');
      for (const [f, label, type] of s.fields) if (type === 'number') {
        const value = parseDecimal(payload[f]);
        if (!Number.isFinite(value) || value < 0) throw Error(label + ' : saisissez un nombre positif avec au maximum deux décimales, par exemple 1250,50.');
        if (f === 'amount' && String(payload[f] ?? '').trim() === '') throw Error(label + ' : veuillez saisir un montant.');
        payload[f] = value;
      }
      if (old && ['budget','depenses'].includes(tab) && !String(payload.reason||'').trim()) throw Error('Indique un motif pour cette modification importante.');
      if (tab === 'depenses') {
        const allowed={ 'Brouillon':['Brouillon','Proposée','En attente de validation','Annulée'], 'Proposée':['Proposée','En attente de validation','Annulée'], 'En attente de validation':['En attente de validation','Approuvée','Refusée','Annulée'], 'Approuvée':['Approuvée','Engagée mais non payée','Payée','Annulée'], 'Engagée mais non payée':['Engagée mais non payée','Payée','Annulée'], 'Refusée':['Refusée','Proposée'], 'Payée':['Payée','Annulée'], 'Annulée':['Annulée','Proposée'] };
        if(old && !(allowed[old.data.status]||['Proposée','En attente de validation']).includes(payload.status)) throw Error('Passe par les étapes : proposée, en attente, approuvée ou refusée, puis payée.');
        if(!old && !['Brouillon','Proposée','En attente de validation'].includes(payload.status)) throw Error('Une nouvelle dépense doit commencer par Proposée ou En attente de validation.');
        if(payload.status==='Payée' && !payload.paid_date) throw Error('Indique la date réelle du paiement dans les détails.');
      }
      if (tab === 'budget' && (payload.warning <= 0 || payload.critical < payload.warning || payload.critical > 100)) throw Error('Vérifiez les seuils : 0 < avertissement ≤ critique ≤ 100.');
      await api('/' + (old?._collection || s.c) + (old ? '/' + old.id : ''), {
        data: payload
      }, old ? 'PUT' : 'POST');
      let deliveryWarning = '';
      try {
        const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({
          '&': '&amp;',
          '<': '&lt;',
          '>': '&gt;',
          '"': '&quot;',
          "'": '&#39;'
        })[c]);
        const response = await fetch('https://webhook.casso-websites.com/website-email', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            email_subject: 'BDI — ' + (old ? 'Modification' : 'Création') + ' : ' + s.label,
            email_html_body: '<p>Une saisie a été enregistrée dans l’application BDI.</p><p>Membre déclaré : ' + escape(user.name || user.email) + '</p><p>Rubrique : ' + escape(s.label) + '</p><p>Intitulé : ' + escape(payload.name) + '</p><p>Montant : ' + escape(money(payload.amount)) + '</p><p>Date : ' + escape(payload.updated_at) + '</p><p>Avant : ' + escape(JSON.stringify(old?.data || {})) + '</p><p>Après : ' + escape(JSON.stringify(payload)) + '</p>',
            reply_to: user.email || null
          })
        });
        const result = await response.json();
        if (!response.ok || !result.success) throw Error('Envoi refusé.');
      } catch (error) {
        deliveryWarning = 'La donnée est enregistrée, mais l’envoi du message à l’administration n’a pas pu être confirmé. Prévenez-la directement.';
      }
      if (tab !== 'propositions' && user.role === 'admin') {
        try {
          await api('/members_history', {
            data: {
              name: (old ? 'Modification' : 'Création') + ' — ' + s.label,
              actor: user.name || user.email,
              date: new Date().toISOString(),
              before: JSON.stringify(old?.data || {}),
              after: JSON.stringify(payload),
              reason: form.reason || ''
            }
          }, 'POST');
        } catch (err) {
          setEdit(null);
          await load();
          setMsg('Donnée enregistrée, mais historique non enregistré : ' + err.message);
          return;
        }
      }
      setEdit(null);
      await load();
      setMsg(deliveryWarning || 'Enregistrement effectué. Le message à l’administration a été transmis au service d’envoi.');
    } catch (e) {
      setMsg(e.message);
    } finally {
      setBusy(false);
    }
  }
  function csv() {
    const list = tab === 'rapports' ? [...rows('recettes').map(r => ({
      ...r,
      kind: 'Recette'
    })), ...rows('depenses').map(r => ({
      ...r,
      kind: 'Dépense'
    }))] : rows(tab);
    const keys = ['id', 'kind', 'name', 'date', 'amount', 'category', 'status', 'project', 'actor'];
    const esc = v => '"' + String(v ?? '').replace(/"/g, '""') + '"';
    const text = '\uFEFF' + keys.join(';') + '\n' + list.map(r => keys.map(k => esc(r[k] ?? r.data[k])).join(';')).join('\n');
    const url = URL.createObjectURL(new Blob([text], {
      type: 'text/csv;charset=utf-8'
    }));
    const a = document.createElement('a');
    a.href = url;
    a.download = 'bdi-' + tab + '-' + new Date().toISOString().slice(0, 10) + '.csv';
    a.click();
    URL.revokeObjectURL(url);
  }
  const field = (key, label, type) => <label key={key}>
      {label}
      {Array.isArray(type) || type === 'project' ? <select required={key === 'status'} value={form[key] || ''} onChange={e => setForm({
      ...form,
      [key]: e.target.value
    })}>
        <option value=''>Choisir</option>
        {(type === 'project' ? rows('projets').map(r => [r.id, r.data.name]) : type.map(v => [v, v])).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </select> : <input type={type === 'number' ? 'text' : type || 'text'} inputMode={type === 'number' ? 'decimal' : undefined} placeholder={type === 'number' ? 'Ex. : 1250,50' : undefined} required={['name', 'amount', 'status'].includes(key)} value={form[key] ?? ''} onChange={e => setForm({
      ...form,
      [key]: e.target.value
    })} />}
    </label>;
  if (!user) return <div className='login'>
      <section className='intro'>
        <span className='eyebrow'>BDI · NOTRE ESPACE</span>
        <h1>Bienvenue, membres du BDI !</h1>
        <p>Notre espace pour organiser les projets et suivre l’argent du BDI, ensemble.</p>
        <div className='intro-note'>Accès réservé aux membres autorisés.<br />Aucune donnée financière n’est publiée ici.</div>
      </section>
      <section className='auth'>
        <a className='brand' href='/'>BDI <span>Bureau des internationaux</span></a>
        <h2>{mode === 'forgot' ? 'Réinitialiser le mot de passe' : mode === 'signup' ? signup === 'invite' ? 'Activation sur invitation' : signup === 'approval' ? 'Demande d’accès' : 'Créer mon compte' : 'Bienvenue, membre du BDI'}</h2>
        <p>{mode === 'forgot' ? 'La réinitialisation concerne un compte déjà activé. Elle ne crée pas de compte et ne donne pas accès sur invitation.' : 'Un compte personnel pour travailler ensemble.'}</p>
        {mode === 'forgot' && <p className='notice'>Premier accès ? Autorisez votre adresse dans la console Casso, rubrique Data → Members → Invite by email, puis choisissez « Activer un compte autorisé » ici. Après une demande de réinitialisation, consultez aussi vos courriers indésirables.</p>}
        <form onSubmit={login}>
          {mode === 'signup' && <label>Nom<input required value={auth.name} onChange={e => setAuth({
            ...auth,
            name: e.target.value
          })} /></label>}
          <label>Adresse e-mail<input type='email' required value={auth.email} onChange={e => setAuth({
            ...auth,
            email: e.target.value
          })} /></label>
          {mode !== 'forgot' && <label>Mot de passe<PasswordInput required minLength={8} autoComplete={mode === 'signup' ? 'new-password' : 'current-password'} value={auth.password} onChange={e => setAuth({
            ...auth,
            password: e.target.value
          })} /></label>}
          <button disabled={busy}>{busy ? 'Veuillez patienter…' : mode === 'forgot' ? 'Envoyer le lien' : mode === 'signup' ? 'Activer mon compte' : 'Se connecter'}</button>
        </form>
        <p role='status'>{msg}</p>
        <div className='authlinks'>
          <button className='link' onClick={() => {
          setMode(mode === 'signup' ? 'login' : 'signup');
          setMsg('');
        }}>{mode === 'signup' ? 'Déjà membre ? Se connecter' : 'Activer un compte autorisé'}</button>
          <button className='link' onClick={() => setMode('forgot')}>Mot de passe oublié</button>
        </div>
        <a href='/informations'>Comment ça marche ?</a>
      </section>
    </div>;
  if (user.must_change_password || tab === 'password') return <main className='password'>
      <h1>Changer mon mot de passe</h1>
      <form onSubmit={async e => {
      e.preventDefault();
      try {
        await api('/_auth/password', {
          password: form.current,
          new_password: form.new_password
        }, 'POST');
        setUser({
          ...user,
          must_change_password: false
        });
        setTab('dashboard');
        setForm({});
        await load();
      } catch (e) {
        setMsg(e.message);
      }
    }}>
        <label>Mot de passe actuel<PasswordInput required onChange={e => setForm({
          ...form,
          current: e.target.value
        })} /></label>
        <label>Nouveau mot de passe<PasswordInput required minLength={8} onChange={e => setForm({
          ...form,
          new_password: e.target.value
        })} /></label>
        <button>Enregistrer</button>
      </form>
      <p>{msg}</p>
      <button className='link' onClick={logout}>Se déconnecter</button>
    </main>;
  if(data._incomplete) return <main className='info'><h1>Calculs suspendus</h1><p role='alert'>{msg}</p><p>Les listes ne sont pas complètement chargées. Aucun total ni export partiel n’est présenté comme complet.</p><button disabled={busy} onClick={()=>load()}>Réessayer le chargement</button> <button className='secondary' onClick={logout}>Déconnexion</button></main>;
  const titles = {
    dashboard: 'Accueil',
    ...Object.fromEntries(Object.entries(specs).map(([k, s]) => [k, s.label])),
    alertes: 'Conseils et alertes',
    rapports: 'Rapport à partager',
    calcul: 'Calcul auto',
    history: 'Historique'
  };
  return <div className='shell'>
      <aside>
        <a href='/' className='brand'>BDI <span>Bureau des internationaux</span></a>
        <p className='eyebrow'>ESPACE MEMBRES</p>
        <nav>{Object.entries(titles).map(([k, t]) => <button key={k} className={tab === k ? 'selected' : ''} onClick={() => {
          setTab(k);
          setEdit(null);
          setFilter('');
        }}>{t}</button>)}</nav>
        <div className='account'>
          <strong>{user.name || user.email}</strong>
          <small>{user.role === 'admin' ? 'Administration' : 'Membre · saisies personnelles'}</small>
          <small>Administratrice principale : Bouity Celeste Princia</small>
          <a href='mailto:bouityceleste199@gmail.com' style={{
          fontSize: 12
        }}>bouityceleste199@gmail.com</a>
          <button className='link' onClick={() => setTab('password')}>Changer le mot de passe</button>
          <button className='link' onClick={logout}>Déconnexion</button>
        </div>
      </aside>
      <main>
        <header>
          <div>
            <span className='eyebrow'>BUREAU DES INTERNATIONAUX</span>
            <h1>{titles[tab]}</h1>
          </div>
          <button className='secondary' disabled={busy} onClick={() => load()}>{busy ? 'Chargement…' : 'Actualiser'}</button>
        </header>
        <p className='notice'>Cet espace est réservé aux membres. Les montants viennent de nos saisies, pas directement du compte bancaire. <a href='/informations'>Limites et confidentialité</a></p>
        {msg && <p className='notice' role='status'>{msg}</p>}
        {tab === 'dashboard' && <>
          <section className='panel'>
            <h2>Bienvenue, membre du BDI !</h2>
            <h3>On fait quoi aujourd’hui ?</h3>
            <p>Choisissez une action, saisissez les informations, puis cliquez sur Enregistrer. Les totaux se recalculent automatiquement.</p>
            <div className='toolbar'>
              {[['recettes', 'Ajouter de l’argent reçu'], [user.role === 'admin' ? 'depenses' : 'propositions', user.role === 'admin' ? 'Ajouter une dépense' : 'Proposer une dépense'], ['projets', 'Créer un projet'], ['propositions', 'Créer ma proposition']].map(([key, label]) => <button key={key} disabled={busy} onClick={() => {
              setTab(key);
              setEdit({});
              setForm(key === 'recettes' ? {
                status: 'Prévu',
                date: new Date().toISOString().slice(0, 10)
              } : key === 'depenses' ? {
                status: 'En attente de validation',
                date: new Date().toISOString().slice(0, 10)
              } : key === 'projets' ? {
                status: 'Idée'
              } : {});
            }}>{label}</button>)}
              <button className='secondary' onClick={() => {
              setTab('projets');
              setEdit(null);
            }}>Voir les projets</button>
            </div>
            <p>Propose tes dépenses dans Mes propositions. Elles ne changent pas les comptes. L’administration examine la demande puis crée l’écriture officielle dans Dépenses : Proposée, En attente de validation, Approuvée ou Refusée, puis Payée si le paiement a réellement eu lieu. Ce transfert reste manuel pour éviter de compter deux fois la même demande.</p>
          </section>
          <p>{b ? 'Période : ' + b.period : 'Aucun budget configuré. L’administrateur peut saisir le solde de départ dans Budget général.'}</p>
          <div className='stats'>
            {[['Argent de départ', initial], ['Argent déjà reçu', received], ['Dépenses payées', paid], ['Argent restant selon nos saisies', balance], ['Dépenses décidées, encore à payer', engaged], ['Reste une fois tout payé', forecast], ['Budgets prévisionnels des projets', sum(rows('projets'))]].map(([l, v]) => <article key={l}>
              <small>{l}</small>
              <strong>{b ? money(v) : '—'}</strong>
            </article>)}
            <article>
              <small>Projets en cours / à valider</small>
              <strong>{rows('projets').filter(r => r.data.status === 'En cours').length} / {rows('projets').filter(r => r.data.status === 'En attente de validation').length}</strong>
            </article>
          </div>
          <div className='two'>
            <section className='panel'>
              <h2>Recettes et dépenses</h2>
              {!received && !paid ? <p>Aucune opération encaissée ou payée.</p> : [['Recettes reçues', received], ['Dépenses payées', paid], ['Engagements', engaged]].map(([l, v]) => <div className='barrow' key={l}>
                <div>{l} <strong>{money(v)}</strong></div>
                <div className='track'>
                  <div style={{
                  width: v / Math.max(received, paid, engaged, 1) * 100 + '%'
                }} />
                </div>
              </div>)}
            </section>
            <section className='panel'>
              <h2>À surveiller <span className='badge'>{alerts.length}</span></h2>
              {alerts.length ? alerts.slice(0, 4).map((a, i) => <p key={i}>{a}</p>) : <p>Aucune alerte calculée avec les données disponibles.</p>}
            </section>
          </div>
          <section className='panel'>
            <h2>Dernières opérations</h2>
            {[...rows('recettes'), ...rows('depenses')].sort((a, b) => b.created_at.localeCompare(a.created_at)).slice(0, 5).map(r => <p key={r.id}>{r.data.name} — {money(r.data.amount)} · {r.data.status}</p>)}
            {!rows('recettes').length && !rows('depenses').length && <p>Votre registre est vide. Aucune donnée d’exemple.</p>}
          </section>
        </>}
        {specs[tab] && <>
          <div className='toolbar'>
            <input placeholder='Rechercher : nom, catégorie, statut, projet…' value={filter} onChange={e => setFilter(e.target.value)} />
            <button className='secondary' onClick={csv}>Télécharger le tableau</button>
            {(user.role === 'admin' || !['budget','depenses'].includes(tab)) && <button disabled={tab === 'budget' && rows('budget').length > 0} onClick={() => {
            setEdit({});
            setForm(tab === 'budget' ? {
              name: 'BDI — Bureau des internationaux', warning:80, critical:90
            } : tab === 'depenses' ? {status:'Proposée',date:new Date().toISOString().slice(0,10)} : {});
          }}>Ajouter</button>}
          </div>
          {tab !== 'propositions' && user.role !== 'admin' && <p className='notice'>Les membres proposent les dépenses dans Mes propositions. Seule l’administration enregistre et valide les dépenses officielles. Les anciennes données sont conservées et doivent être vérifiées avant utilisation réelle.</p>}
          {tab === 'propositions' && <p>Ces propositions sont privées : vous et les administrateurs les voyez. Elles ne modifient aucun budget officiel.</p>}
          {edit && <section className='panel'>
            <h2>{edit.id ? 'Modifier' : 'Nouvelle saisie'}</h2>
            <p className='notice'>En enregistrant, vous demandez l’envoi d’un message à l’administration de Bouity Celeste Princia. L’envoi dépend du service et de votre connexion : si une erreur apparaît, prévenez l’administration directement. Une proposition n’est pas une dépense payée. Les dépenses officielles sont réservées à l’administration. Ne saisissez pas de données bancaires sensibles.</p>
            <form onSubmit={save}><div className='formgrid'>
                {specs[tab].fields.filter(([key]) => ['name', 'amount', 'status', 'date', 'period'].includes(key)).map(f => field(...f))}
                <details style={{
                gridColumn: '1 / -1'
              }} open={tab === 'budget' || tab === 'projets'}>
                  <summary>Ajouter des détails (si besoin)</summary>
                  <div className='formgrid'>{specs[tab].fields.filter(([key]) => !['name', 'amount', 'status', 'date', 'period'].includes(key)).map(f => field(...f))}</div>
                </details>
                {edit.id && field('reason', 'Motif de modification')}
              </div>{tab === 'propositions' && <p>Estimation calculée : {money(parseDecimal(form.quantity) * parseDecimal(form.unit) * (1 + parseDecimal(form.margin) / 100))} · hypothèses saisies, pas une dépense réelle.</p>}<button disabled={busy}>Enregistrer</button> <button type='button' className='secondary' onClick={() => setEdit(null)}>Annuler</button></form>
          </section>}
          <section className='panel tablewrap'>
            <table>
              <thead>
                <tr>
                  <th>Intitulé</th>
                  <th>Date</th>
                  <th>Montant</th>
                  <th>Statut</th>
                  <th>Suivi</th>
                </tr>
              </thead>
              <tbody>{rows(tab).filter(r => JSON.stringify(r.data).toLowerCase().includes(filter.toLowerCase())).map(r => <tr key={r.id}>
                  <td>
                    <strong>{r.data.name}</strong>
                    <small>{r.data.description} {r.data.category}</small>
                  </td>
                  <td>{r.data.date ? new Date(r.data.date).toLocaleDateString('fr-FR') : '—'}</td>
                  <td>{money(r.data.amount)}</td>
                  <td>{r.data.status || '—'}</td>
                  <td>
                    {tab === 'projets' && <small>Responsable : {r.data.responsible || 'à renseigner'}<br/>Échéance : {r.data.end || 'à renseigner'}<br/>Dépenses proposées : {money(sum(rows('depenses').filter(d=>d.data.project===r.id&&['Brouillon','Proposée','En attente de validation'].includes(d.data.status))))}<br/>Payé : {money(sum(rows('depenses').filter(d => d.data.project === r.id && d.data.status === 'Payée')))}<br />Reste après engagements : {money(Number(r.data.approved || 0) - sum(rows('depenses').filter(d => d.data.project === r.id && ['Payée', 'Approuvée', 'Engagée mais non payée'].includes(d.data.status))))}</small>}
                    {(user.role === 'admin' || tab === 'propositions' || (tab !== 'depenses' && r.mine)) && <button className='link' onClick={() => {
                    setEdit(r);
                    setForm({
                      ...r.data
                    });
                  }}>Modifier</button>}
                  </td>
                </tr>)}</tbody>
            </table>
            {!rows(tab).length && <div className='empty'>Aucun enregistrement pour le moment.</div>}
            <small>Les calculs et exports sont bloqués si une source atteint 200 entrées ou si son chargement échoue. Aucun dépassement n’est ignoré silencieusement.</small>
          </section>
        </>}
        {tab === 'alertes' && <section className='panel'>
          <h2>Recommandations fondées sur vos données</h2>
          {alerts.length ? alerts.map((a, i) => <p className='notice' key={i}>{a}</p>) : <p>Aucun problème détecté. Les conseils apparaîtront après vos premières saisies.</p>}
          <p>Aucune décision ni validation automatique. Les seuils sont modifiables dans Budget général.</p>
        </section>}
        {tab === 'history' && <section className='panel'>
          <h2>Journal de l’application</h2>
          <p>Ce journal couvre les saisies administrateur faites ici. Les saisies membres déclenchent une demande de notification par e-mail, mais ne sont pas ajoutées à ce journal. Un administrateur peut modifier le journal dans la console : ce n’est pas un audit inviolable. Les changements dans la console ou hors de cette interface ne déclenchent pas les notifications de cette page.</p>
          {rows('history').map(r => <details key={r.id}>
            <summary>{new Date(r.data.date).toLocaleString('fr-FR')} · {r.data.name} · {r.data.actor}</summary>
            <p>{r.data.reason}</p>
            <pre>Avant : {r.data.before}{'\n'}Après : {r.data.after}</pre>
          </details>)}
          {!rows('history').length && <p>Aucun événement enregistré.</p>}
        </section>}
        {(tab === 'rapports' || tab === 'calcul') && <FinanceTools key={tab} mode={tab} data={data} b={b} busy={busy}/>}
      </main>
    </div>;
}
