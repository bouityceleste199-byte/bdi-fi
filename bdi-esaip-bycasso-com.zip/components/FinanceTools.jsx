import React, { useState } from 'react';
const euro = n => new Intl.NumberFormat('fr-FR', {
  style: 'currency',
  currency: 'EUR'
}).format(n);
const cents = n => Math.round(Number(n || 0) * 100);
const total = rs => rs.reduce((s, r) => s + cents(r.data.amount), 0);
const date = s => s ? new Date(s + 'T12:00:00').toLocaleDateString('fr-FR') : 'Non renseignée';
export default function FinanceTools({
  mode,
  data,
  b,
  busy
}) {
  const [month, setMonth] = useState(''), [projectId, setProjectId] = useState('');
  const [start, S] = useState(''),
    [end, E] = useState(''),
    [lines, L] = useState([{
      name: '',
      quantity: '',
      price: ''
    }]),
    [margin, M] = useState(''),
    [expected, X] = useState('');
  const rows = k => data[k] || [];
  const receipts = rows('recettes'),
    expenses = rows('depenses'),
    projects = rows('projets');
  const paid = expenses.filter(r => r.data.status === 'Payée'),
    received = receipts.filter(r => r.data.status === 'Reçu'),
    engaged = expenses.filter(r => ['Approuvée', 'Engagée mais non payée'].includes(r.data.status));
  const balance = cents(b?.amount) + total(received) - total(paid),
    remaining = balance - total(engaged);
  const truncated = Object.values(data).some(rs => Array.isArray(rs) && Object.values(rs.reduce((a, r) => (a[r._collection || 'other'] = (a[r._collection || 'other'] || 0) + 1, a), {})).some(n => n >= 200));
  const metrics = [['Argent de départ', b ? euro(cents(b.amount) / 100) : 'Non renseigné'], ['Argent déjà reçu', euro(total(received) / 100)], ['Dépenses déjà payées', euro(total(paid) / 100)], ['Dépenses décidées, encore à payer', euro(total(engaged) / 100)], ['Argent restant selon nos saisies', b ? euro(balance / 100) : 'Budget de départ à saisir'], ['Reste une fois tout payé', b ? euro(remaining / 100) : 'Budget de départ à saisir']];
  const cards = <div className='stats'>{metrics.map(([name, value]) => <article key={name}>
        <small>{name}</small>
        <strong>{value}</strong>
      </article>)}</div>;
  const warning = <p className='notice'>Calculs faits avec les données chargées. {truncated ? 'ATTENTION : une liste atteint 200 entrées ; les totaux peuvent être incomplets. Ne pas utiliser ce rapport comme bilan complet.' : 'Le chargement est bloqué dès qu’une source atteint 200 entrées : aucun export n’est alors proposé.'} Les montants ne viennent pas directement du compte bancaire.</p>;
  const byCategory = {};
  paid.forEach(r => {
    const key = r.data.category || 'Sans catégorie';
    byCategory[key] = (byCategory[key] || 0) + cents(r.data.amount);
  });
  const categories = <table>
      <thead>
        <tr>
          <th>Catégorie</th>
          <th>Dépenses payées</th>
        </tr>
      </thead>
      <tbody>{Object.entries(byCategory).sort((a, b) => b[1] - a[1]).map(([k, n]) => <tr key={k}>
          <td>{k}</td>
          <td>{euro(n / 100)}</td>
        </tr>)}</tbody>
    </table>;
  const projectTable = <table>
      <thead>
        <tr>
          <th>Projet</th>
          <th>Prévision / budget autorisé</th><th>Responsable / échéance</th><th>Dépenses proposées</th>
          <th>Payé</th>
          <th>Encore à payer</th>
          <th>Reste après paiements</th>
        </tr>
      </thead>
      <tbody>{projects.map(p => {
        const spent = total(paid.filter(r => r.data.project === p.id)),
          due = total(engaged.filter(r => r.data.project === p.id));
        return <tr key={p.id}>
          <td>{p.data.name}</td>
          <td>{euro(Number(p.data.amount||0))} / {euro(Number(p.data.approved || 0))}</td><td>{p.data.responsible||'—'}<br/>{date(p.data.end)}</td><td>{euro(total(expenses.filter(r=>r.data.project===p.id&&['Brouillon','Proposée','En attente de validation'].includes(r.data.status)))/100)}</td>
          <td>{euro(spent / 100)}</td>
          <td>{euro(due / 100)}</td>
          <td>{euro((cents(p.data.approved) - spent - due) / 100)}</td>
        </tr>;
      })}</tbody>
    </table>;
  function decimal(v) {
    const s = String(v || '').replace(/\s/g, '').replace(',', '.');
    return s === '' ? 0 : /^\d+(?:\.\d{0,2})?$/.test(s) ? Number(s) : NaN;
  }
  const costs = lines.map(l => Math.round(decimal(l.quantity) * decimal(l.price) * 100)),
    subtotal = costs.reduce((a, v) => a + v, 0),
    estimated = subtotal + Math.round(subtotal * decimal(margin) / 100),
    net = estimated - Math.round(decimal(expected) * 100);
  const valid = [...costs, estimated, net].every(Number.isFinite);
  if (mode === 'calcul') return <>
      <section className='panel'>
        <h2>Calcul automatique de nos comptes</h2>
        <p>Tu n’as rien à additionner : après chaque enregistrement, le site refait les calculs à partir des statuts.</p>
        {warning}
        {cards}
        <p>Une entrée « Prévu » n’ajoute pas d’argent. Une dépense « Payée » est retirée une seule fois. Les dépenses décidées mais pas encore payées sont comptées séparément.</p>
      </section>
      <section className='panel tablewrap'>
        <h2>Où va notre argent ?</h2>
        {paid.length ? categories : <p>Aucune dépense payée pour le moment.</p>}
      </section>
      <section className='panel tablewrap'>
        <h2>Les comptes de chaque projet</h2>
        {projects.length ? projectTable : <p>Aucun projet enregistré.</p>}
      </section>
      <section className='panel'>
        <h2>Combien coûterait mon idée ?</h2>
        <p>Ce calcul est un brouillon : il ne s’enregistre pas et ne change pas les comptes du BDI. Note les prix que tu connais ; le site ne les invente pas.</p>
        {lines.map((l, i) => <div className='estimate-line' key={i}>
          <label>Article<input value={l.name} onChange={e => L(lines.map((x, j) => j === i ? {
            ...x,
            name: e.target.value
          } : x))} /></label>
          <label>Quantité<input inputMode='decimal' value={l.quantity} placeholder='Ex. : 3' onChange={e => L(lines.map((x, j) => j === i ? {
            ...x,
            quantity: e.target.value
          } : x))} /></label>
          <label>Prix d’un article (€)<input inputMode='decimal' value={l.price} placeholder='Ex. : 12,50' onChange={e => L(lines.map((x, j) => j === i ? {
            ...x,
            price: e.target.value
          } : x))} /></label>
          <strong>{Number.isFinite(costs[i]) ? euro(costs[i] / 100) : 'Nombre à corriger'}</strong>
          <button className='link' onClick={() => L(lines.filter((_, j) => j !== i))}>Retirer</button>
        </div>)}
        <button className='secondary' onClick={() => L([...lines, {
        name: '',
        quantity: '',
        price: ''
      }])}>Ajouter un article</button>
        <div className='formgrid' style={{
        marginTop: 20
      }}>
          <label>Marge pour les imprévus (%)<input inputMode='decimal' value={margin} onChange={e => M(e.target.value)} /></label>
          <label>Argent attendu pour cette idée (€)<input inputMode='decimal' value={expected} onChange={e => X(e.target.value)} /></label>
        </div>
        {valid ? <>
          <p>Total des articles : <strong>{euro(subtotal / 100)}</strong></p>
          <p>Total avec imprévus : <strong>{euro(estimated / 100)}</strong></p>
          <p>À financer après l’argent attendu : <strong>{euro(Math.max(0, net) / 100)}</strong>{net < 0 ? ' · Excédent estimé : ' + euro(-net / 100) : ''}</p>
          {b && <p>Argent disponible après engagements : {euro(remaining / 100)}. {net > remaining ? 'Il manque ' + euro((net - remaining) / 100) + ' selon ces hypothèses.' : 'Cette estimation tient dans le montant disponible.'}</p>}
          <small>L’argent attendu est une hypothèse, pas une recette déjà reçue.</small>
        </> : <p role='alert'>Vérifie les nombres : utilise par exemple 12,50, sans symbole €.</p>}
      </section>
    </>;
  const badDates = start && end && start > end;
  const within = r => {
    const d = r.kind === 'Dépense' ? r.data.paid_date || r.data.date : r.data.date;
    return (!projectId || r.data.project === projectId) && ((!start && !end) || (!!d && (!start || d >= start) && (!end || d <= end)));
  };
  const ops = [...receipts.map(r => ({
    ...r,
    kind: 'Argent reçu / prévu'
  })), ...expenses.map(r => ({
    ...r,
    kind: 'Dépense'
  }))].filter(within).sort((a, b) => (a.data.paid_date || a.data.date || '').localeCompare(b.data.paid_date || b.data.date || ''));
  const filteredPaid = ops.filter(r => r.kind === 'Dépense' && r.data.status === 'Payée'),
    filteredReceived = ops.filter(r => r.kind !== 'Dépense' && r.data.status === 'Reçu');
  function downloadCsv(){
    const columns=['Date','Type','Description','Projet','Statut','Montant EUR'];
    const escape=value=>{let text=String(value??'');if(/^[=+@\-\t\r]/.test(text)) text="'"+text;return '"'+text.replace(/"/g,'""')+'"';};
    const content='\uFEFF'+['BDI — Bureau des internationaux', 'Généré le '+new Date().toLocaleString('fr-FR'), 'Période : '+(start||'début')+' au '+(end||'fin')+' ; Projet : '+(projects.find(p=>p.id===projectId)?.data.name||'Tous')].map(escape).join('\n')+'\n'+columns.map(escape).join(';')+'\n'+ops.map(r=>[r.kind==='Dépense'?(r.data.paid_date||r.data.date):r.data.date,r.kind,r.data.name,projects.find(p=>p.id===r.data.project)?.data.name||'',r.data.status,Number(r.data.amount||0).toFixed(2).replace('.',',')].map(escape).join(';')).join('\n');
    const url=URL.createObjectURL(new Blob([content],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='bdi-rapport-'+(month||'periode')+'.csv';a.click();URL.revokeObjectURL(url);
  }
  return <>
      <div className='panel report-controls'>
        <h2>Préparer le rapport mensuel ou par projet</h2><div className='formgrid'><label>Mois<input type='month' value={month} onChange={e=>{const value=e.target.value;setMonth(value);if(value){S(value+'-01');const [year,m]=value.split('-').map(Number);E(value+'-'+new Date(year,m,0).getDate());}else{S('');E('');}}}/></label><label>Projet<select value={projectId} onChange={e=>setProjectId(e.target.value)}><option value=''>Tous les projets</option>{projects.map(p=><option value={p.id} key={p.id}>{p.data.name}</option>)}</select></label></div>
        <p>Choisis les dates de la liste des opérations, puis clique sur le bouton. Dans la fenêtre d’impression, choisis <strong>Enregistrer au format PDF</strong>. Tu pourras partager le fichier obtenu.</p>
        <div className='formgrid'>
          <label>Du<input type='date' value={start} onChange={e => S(e.target.value)} /></label>
          <label>Au<input type='date' value={end} onChange={e => E(e.target.value)} /></label>
        </div>
        {badDates && <p role='alert'>La date de fin doit être après la date de début.</p>}
        <button className='secondary' disabled={busy || badDates || truncated} onClick={downloadCsv}>Télécharger les opérations en CSV</button> <button disabled={busy || badDates || truncated} onClick={() => window.print()}>Enregistrer le rapport en PDF / Imprimer</button>
        <p>Le fichier contient des informations internes : partage-le seulement avec les personnes autorisées. Les téléchargements ne restent pas protégés par la connexion au site.</p>
      </div>
      <article className='print-report'>
        <h2>BDI — Bureau des internationaux</h2>
        <h3>{month?'Rapport du mois '+month:'Rapport des comptes et des projets'}</h3><p>Projet sélectionné : {projects.find(p=>p.id===projectId)?.data.name||'Tous les projets'}</p>
        <p>Généré le {new Date().toLocaleString('fr-FR')} · Période du budget : {b?.period || 'non définie'}.</p>
        {warning}
        <section className='panel'>
          <h2>1. Nos comptes aujourd’hui</h2>
          <p>Ces totaux couvrent toutes les opérations chargées, même si des dates ont été choisies pour la liste ci-dessous. Il ne s’agit pas d’un historique du solde à une ancienne date.</p>
          {cards}
        </section>
        <section className='panel tablewrap'>
          <h2>2. Dépenses payées par catégorie — toutes les dates</h2>
          {paid.length ? categories : <p>Aucune dépense payée.</p>}
        </section>
        <section className='panel tablewrap'>
          <h2>3. Nos projets aujourd’hui</h2>
          {projects.length ? projectTable : <p>Aucun projet enregistré.</p>}{projects.filter(p=>!projectId||p.id===projectId).map(p=><div key={p.id}><h3>Bilan : {p.data.name}</h3><p>{p.data.status==='Terminé'?'Projet terminé':'Bilan provisoire — projet non terminé'}</p><p>Responsable : {p.data.responsible||'non renseigné'} · Échéance : {date(p.data.end)}</p><p>{p.data.final_summary||'Aucun bilan final rédigé.'}</p></div>)}
        </section>
        <section className='panel tablewrap'>
          <h2>4. Les opérations {start || end ? 'sur la période choisie' : 'enregistrées'}</h2>
          <p>Du {start ? date(start) : 'début'} au {end ? date(end) : 'dernier enregistrement'}. Les dépenses utilisent leur date de paiement si elle existe, sinon la date de demande. Les opérations sans date sont exclues si un filtre de date est actif.</p>
          <p>Argent reçu sur cette sélection : <strong>{euro(total(filteredReceived) / 100)}</strong> · Dépenses payées : <strong>{euro(total(filteredPaid) / 100)}</strong>.</p>
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Type / nom</th>
                <th>Projet</th>
                <th>Statut</th>
                <th>Montant</th>
              </tr>
            </thead>
            <tbody>{!badDates && ops.map(r => <tr key={r._collection + r.id}>
                <td>{date(r.kind === 'Dépense' ? r.data.paid_date || r.data.date : r.data.date)}</td>
                <td>
                  {r.kind}
                  <br />
                  {r.data.name}
                </td>
                <td>{projects.find(p => p.id === r.data.project)?.data.name || '—'}</td>
                <td>{r.data.status}</td>
                <td>{euro(cents(r.data.amount) / 100)}</td>
              </tr>)}</tbody>
          </table>
          {!ops.length && <p>Aucune opération dans cette sélection.</p>}
        </section>
        <p>Rapport calculé à partir des saisies des membres. Ce document ne confirme pas un solde bancaire et ne remplace pas un bilan comptable vérifié.</p>
      </article>
    </>;
}
