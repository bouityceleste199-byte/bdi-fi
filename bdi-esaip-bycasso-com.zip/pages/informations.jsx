import React from 'react';
export const meta = {
  title: 'BDI — À savoir',
  description: 'Comment fonctionne l’espace des membres du Bureau des internationaux, et quelles sont ses limites.',
  lang: 'fr'
};
export default function Informations() {
  return <main className='info'>
      <a className='brand' href='/'>BDI <span>Bureau des internationaux</span></a>
      <h1>À savoir avant de commencer</h1>
      <p>
        <a href='/'>Retour à notre espace</a>
      </p>
      <section className='panel'>
        <h2>Qui peut faire quoi ?</h2>
        <p>Il faut un compte autorisé pour voir les comptes et les projets. Chaque membre peut proposer une dépense dans Mes propositions, ajouter une entrée d’argent ou un projet et modifier ses saisies non financières officielles. Seule l’administration peut modifier les champs des dépenses officielles et attribuer le budget autorisé d’un projet ; ces protections sont appliquées côté serveur. L’administration examine les propositions puis les recopie manuellement dans les dépenses officielles, sans inclure les propositions dans les totaux. Tout cela est visible par les autres membres. Les propositions personnelles sont visibles seulement par leur auteur et les administrateurs.</p>
        <p>L’administration peut modifier toutes les saisies, le budget de départ et les anciennes écritures administratives. Tous les administrateurs ont les mêmes droits. Il n’existe pas encore de droits particuliers pour un trésorier ou un responsable de projet.</p>
      </section>
      <section className='panel'>
        <h2>Quand vous enregistrez une modification</h2>
        <p>L’application demande l’envoi d’un e-mail à l’administration avec les informations avant et après. Cet envoi n’est pas garanti : il dépend de votre connexion et du service d’envoi. Si un message d’erreur apparaît, prévenez directement l’administration. Les changements faits dans la console Casso ou hors de ce formulaire n’envoient pas ce message.</p>
        <p>L’historique du site contient seulement les saisies faites ici par un administrateur. Il peut être modifié par l’administration : ce n’est pas une preuve comptable protégée.</p>
      </section>
      <section className='panel'>
        <h2>Comment sont calculés les montants ?</h2>
        <p>Argent restant = argent de départ + argent reçu − dépenses déjà payées.</p>
        <p>Reste une fois tout payé = argent restant − dépenses décidées mais encore à payer. Une dépense payée n’est pas retirée deux fois.</p>
        <p>Les dépenses d’un projet sont les mêmes que celles de la liste générale. Le site ne lit pas votre compte bancaire : il calcule à partir de ce que vous saisissez.</p>
      </section>
      <section className='panel'>
        <h2>Ce qui est gratuit et ses limites</h2>
        <p>Ce sous-domaine reste hébergé gratuitement sans date de fin. Aucun service payant n’a été activé. Le gratuit accepte 200 comptes, mais les 500 demandes par jour, dont 100 enregistrements ou modifications, sont partagées par tout le groupe. Cela ne garantit pas que 100 personnes puissent utiliser intensivement le site chaque jour.</p>
        <p>Vous pouvez conserver 1 000 entrées au total, avec 32 Ko maximum par entrée. Chaque liste charge au maximum 200 entrées. Dès qu’une source atteint cette limite, que le total annoncé dépasse les lignes reçues, ou qu’un chargement échoue, les calculs et exports sont bloqués. Cette version ne sait pas récupérer les pages suivantes : aucun rapport incomplet ne doit être présenté comme exhaustif. Les anciennes listes administratives et les nouvelles listes membres sont chargées séparément.</p>
        <p>Les informations se mettent à jour quand vous vous connectez, enregistrez ou cliquez sur Actualiser. La rubrique Calcul auto additionne les comptes et permet d’estimer plusieurs articles dans un brouillon non enregistré. Le rapport propose une sélection par mois et par projet et un téléchargement CSV des opérations sélectionnées. Les totaux généraux et les budgets des projets représentent les comptes actuels, pas un ancien solde bancaire ; le filtre de mois porte sur les opérations. Vous pouvez enregistrer ce rapport en PDF grâce à la fenêtre d’impression du navigateur. Les graphiques détaillés et l’historique du solde à une date passée ne sont pas disponibles.</p>
      </section>
      <section className='panel'>
        <h2>Gardez vos documents en sécurité</h2>
        <p>Le site ne conserve pas de factures ou PDF privés. Gardez-les dans un espace de votre établissement réservé aux bonnes personnes. Ne partagez pas de liens publics vers ces documents.</p>
        <p>Vous pouvez télécharger les tableaux et les conserver dans un endroit sécurisé. Ce téléchargement est manuel : il n’existe pas de sauvegarde automatique ni de bouton pour remettre ces données dans le site.</p>
        <p>Ne saisissez pas de numéros de carte, d’informations bancaires sensibles ou de renseignements personnels inutiles. Les règles de conservation des données et de protection des personnes doivent être définies avant l’utilisation réelle.</p>
        <p>Les tests complets avec plusieurs comptes ne sont pas encore réalisés. N’utilisez pas encore cet espace comme outil de comptabilité réelle.</p>
      </section>
      <p>Une question ? Contactez Bouity Celeste Princia : <a href='mailto:bouityceleste199@gmail.com'>bouityceleste199@gmail.com</a>.</p>
      <a href='/'>Retour à notre espace</a>
    </main>;
}
