import React from 'react';
import App from '../components/App.jsx';
export const meta = {
  title: 'BDI — Bureau des internationaux',
  description: 'L’espace des membres du Bureau des internationaux pour organiser leurs projets et suivre leur budget. Accès sur invitation.',
  lang: 'fr'
};
export const jsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: 'BDI — Bureau des internationaux',
  description: 'Bureau des internationaux.',
  url: 'https://bdi-esaip.bycasso.com'
};
export default function Index() {
  return <App />;
}
